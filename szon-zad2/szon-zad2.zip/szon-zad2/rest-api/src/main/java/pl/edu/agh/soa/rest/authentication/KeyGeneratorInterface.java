package pl.edu.agh.soa.rest.authentication;

import java.security.Key;

public interface KeyGeneratorInterface {
    Key generateKey();
}
